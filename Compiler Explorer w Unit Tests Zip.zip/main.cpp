#include <cstdio>
#include <string>
#include "gpio/gpio.h"
#include "api/api.h"

#define LED_PIN (1)

#if defined(RUN_UNIT_TESTS)
// File for unit tests of LED exercise
#include "catch2/catch_test_macros.hpp"

TEST_CASE("Test Case 1: Program LED pin to PICO Default") {
    REQUIRE( LED_PIN == PICO_DEFAULT_LED_PIN );
}

TEST_CASE("Test Case 2: Initialize GPIO to LED Pin") {
    REQUIRE( gpio_init(25) == 25 );
}
#else

void enable_gpio_pin(int led_pin) {
    gpio_init(led_pin);
}

void set_gpio_out(int led_pin) {
    gpio_set_dir(led_pin, GPIO_OUT);
}

void program_gpio_pin(int pin, int value) {
    gpio_put(pin, value);
}

int main() {
    stdio_init_all();
    enable_gpio_pin(LED_PIN);
    set_gpio_out(LED_PIN);
    int count = 2;
    while (count > 0) {
        printf("Hello, GHC Participants!\n");
        program_gpio_pin(LED_PIN, 1);
        sleep_ms(1000);
        program_gpio_pin(LED_PIN, 0);
        sleep_ms(1000);
        count--;
    }
    return 0;
}
#endif