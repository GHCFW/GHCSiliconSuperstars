// File for HW API that we abstracted here
#include "gpio.h"
#include <unistd.h>

#define GPIO_BASE_ADDR (0xd0000000) // Get Base addr from the data sheet

gpio_registers_t *gpio_regs_t = (gpio_registers_t *)GPIO_BASE_ADDR;

gpio_registers_t *gpio_regs = (gpio_registers_t*)malloc(sizeof(gpio_regs_t));

int gpio_init(int led_pin) {
    //pin_directions::insert(led_pin);
    return 5;
}

static inline void gpio_set_dir_out_masked(uint32_t mask) {
    printf("addr of gpio_regs 0x%x, gpio_oe_set 0x%x\n",gpio_regs, &gpio_regs->gpio_oe_set);
    gpio_regs->gpio_oe_set = mask;
    printf("data in gpio_oe_set 0x%x\n", gpio_regs->gpio_oe_set);
 }
  
 static inline void gpio_set_dir_in_masked(uint32_t mask) {
    gpio_regs->gpio_oe_clr = mask;
 }
  
 static inline void gpio_set_dir_masked(uint32_t mask, uint32_t value) {
    gpio_regs->gpio_oe_togl = (gpio_regs->gpio_oe ^ value) & mask;
 }
  
 static inline void gpio_set_dir_all_bits(uint32_t values) {
    gpio_regs->gpio_oe = values;
 } 

void gpio_set_dir(int pin, GPIO_DIR out) {
    printf("addr of gpio_regs_t 0x%x, gpio_reg 0x%x\n", gpio_regs_t, gpio_regs);
    uint32_t mask = 1ul << pin;
    printf("set pin dir, mask: 0x%x\n", mask);
    if (out == GPIO_OUT)
        gpio_set_dir_out_masked(mask);
    else
        gpio_set_dir_in_masked(mask);
}

void gpio_put(int pin, int value) {
    //Do nothing
}

