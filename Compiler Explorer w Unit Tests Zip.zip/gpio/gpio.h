#pragma once
#include <cstdint>
#include <cstdlib>
#include <cstdio>

#define PICO_DEFAULT_LED_PIN (25)

typedef enum
{
    GPIO_IN = false,
    GPIO_OUT = true,
    GPIO_DIR_MAX
} GPIO_DIR;

int gpio_init(int pin);
void gpio_set_dir(int pin, GPIO_DIR direction);
GPIO_DIR gpio_get_dir(int pin);
void gpio_put(int pin, int value);
int gpio_get(int pin);

//Reference to datasheet: https://datasheets.raspberrypi.com/rp2040/rp2040-datasheet.pdf#tab-registerlist_sio
typedef struct {
     // Processor core identifier
     const volatile uint32_t cpuid;
  
     // Input value for GPIO pins
     // 0x3fffffff [29:0]  : GPIO_IN (0): Input value for GPIO0
     const volatile uint32_t gpio_in;
  
     // Input value for QSPI pins
     // 0x0000003f [5:0]   : GPIO_HI_IN (0): Input value on QSPI IO in order 0
     const volatile uint32_t gpio_hi_in;
  
     uint32_t _pad0;
  
     // GPIO output value
     // 0x3fffffff [29:0]  : GPIO_OUT (0): Set output level (1/0 -> high/low) for GPIO0
     const volatile uint32_t gpio_out;
  
     // GPIO output value set
     // 0x3fffffff [29:0]  : GPIO_OUT_SET (0): Perform an atomic bit-set on GPIO_OUT, i
     volatile uint32_t gpio_set;
  
     // GPIO output value clear
     // 0x3fffffff [29:0]  : GPIO_OUT_CLR (0): Perform an atomic bit-clear on GPIO_OUT, i
     volatile uint32_t gpio_clr;
  
     // GPIO output value XOR
     // 0x3fffffff [29:0]  : GPIO_OUT_XOR (0): Perform an atomic bitwise XOR on GPIO_OUT, i
     volatile uint32_t gpio_togl;
  
     // GPIO output enable
     // 0x3fffffff [29:0]  : GPIO_OE (0): Set output enable (1/0 -> output/input) for GPIO0
     volatile uint32_t gpio_oe;
  
     // GPIO output enable set
     // 0x3fffffff [29:0]  : GPIO_OE_SET (0): Perform an atomic bit-set on GPIO_OE, i
     volatile uint32_t gpio_oe_set;
  
     // GPIO output enable clear
     // 0x3fffffff [29:0]  : GPIO_OE_CLR (0): Perform an atomic bit-clear on GPIO_OE, i
     volatile uint32_t gpio_oe_clr;
  
     // GPIO output enable XOR
     // 0x3fffffff [29:0]  : GPIO_OE_XOR (0): Perform an atomic bitwise XOR on GPIO_OE, i
     volatile uint32_t gpio_oe_togl;
} gpio_registers_t;