#pragma once

void stdio_init_all();
void sleep_ms(int time_in_ms);