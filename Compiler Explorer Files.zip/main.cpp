#include <cstdio>
#include <string>
#include "gpio/gpio.h"
#include "api/api.h"

#define LED_PIN (1)
#define SLEEP_IN_MS (1000)

#if defined(RUN_UNIT_TESTS)
// Include Catch2 unit testing framework
#include "catch2/catch_test_macros.hpp"

TEST_CASE("Demo Test Case: Program LED pin to PICO Default") {
    // Figure out which GPIO is connected to the LED pin and update the define
    REQUIRE( LED_PIN == PICO_DEFAULT_LED_PIN );
}

#else

void enable_gpio_pin(uint32_t led_pin) {
    gpio_init(led_pin);
}

void set_gpio_out(uint32_t led_pin) {
    gpio_set_dir(led_pin, GPIO_OUT);
}

void program_gpio_pin(uint32_t pin, uint32_t value) {
    gpio_put(pin, value);
}

void cleanup() {
    cleanup_gpio();
}

int main() {
    stdio_init_all();
    printf("Hello, GHC Participants!\n");
    enable_gpio_pin(LED_PIN);
    set_gpio_out(LED_PIN);
    int count = 2;
    while (count > 0) {
        // Program LED_PIN to value 1
        sleep_ms(SLEEP_IN_MS);
        // Program LED_PIN to value 0
        sleep_ms(SLEEP_IN_MS);
        count--;
    }
    cleanup();
    return 0;
}
#endif