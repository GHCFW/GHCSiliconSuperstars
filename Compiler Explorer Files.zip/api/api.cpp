#include <unistd.h>
#include "api.h"

void stdio_init_all() {
    //To enable UART messages in Raspberry Pi Pico
    //https://raspberrypi.github.io/pico-sdk-doxygen/group__pico__stdio.html#gadd999f115d6f239056f3b15bfacb3726
}

void sleep_ms(int time_in_ms) {
    //<SW sleep in seconds>
    sleep(time_in_ms/1000);
}