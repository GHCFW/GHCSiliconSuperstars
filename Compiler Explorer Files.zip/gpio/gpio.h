#pragma once
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <unistd.h>

#define dprintf printf

// Reference Documentation: https://raspberrypi.github.io/pico-sdk-doxygen/group__hardware__gpio.html
// Reference code: https://raspberrypi.github.io/pico-sdk-doxygen/gpio_8h_source.html

// TODO: Move this to LED or main
#define PICO_DEFAULT_LED_PIN (25)

// TODO:
// Add a macro for enabling debug prints

#define GPIO_OUT (true)
#define GPIO_IN (false)

// This struct represents GPIO memory mapped registers used for configuring GPIOs.
// Datasheet: https://datasheets.raspberrypi.com/rp2040/rp2040-datasheet.pdf#tab-registerlist_sio
// Elements marked as unused are registers that are not used for this workshop, but are still valid registers for GPIO configuration as defined in Raspberry Pi Pico Datasheet
typedef struct gpio_registers_t {
    // Processor core identifier
    const uint32_t cpuid_unused;
  
    // Input value for GPIO pins
    // 0x3fffffff [29:0]  : GPIO_IN (0): Input value for GPIO0
    // HW would have this as a Read-Only but for the sake of running this OFF_TARGET we have modified it to allow the tests write to it
    volatile uint32_t gpio_in;
  
    const uint32_t gpio_hi_in_unused;
  
    uint32_t _unused0; // Offset 0xc is not defined in the SDK
  
    // GPIO output value
    // 0x3fffffff [29:0]  : GPIO_OUT (0): Set output level (1/0 -> high/low) for GPIO0
    volatile uint32_t gpio_out;
  
    // GPIO output value set
    // 0x3fffffff [29:0]  : GPIO_OUT_SET (0): Perform an atomic bit-set on GPIO_OUT, i
    volatile uint32_t gpio_set;
  
    // GPIO output value clear
    // 0x3fffffff [29:0]  : GPIO_OUT_CLR (0): Perform an atomic bit-clear on GPIO_OUT, i
    volatile uint32_t gpio_clr;
  
    // GPIO output value XOR
    // 0x3fffffff [29:0]  : GPIO_OUT_XOR (0): Perform an atomic bitwise XOR on GPIO_OUT, i
    volatile uint32_t gpio_togl;
  
    // GPIO output enable
    // 0x3fffffff [29:0]  : GPIO_OE (0): Set output enable (1/0 -> output/input) for GPIO0
    volatile uint32_t gpio_oe;
  
    // GPIO output enable set
    // 0x3fffffff [29:0]  : GPIO_OE_SET (0): Perform an atomic bit-set on GPIO_OE, i
    volatile uint32_t gpio_oe_set;
  
    // GPIO output enable clear
    // 0x3fffffff [29:0]  : GPIO_OE_CLR (0): Perform an atomic bit-clear on GPIO_OE, i
    volatile uint32_t gpio_oe_clr;
} gpio_registers_t;

extern gpio_registers_t* gpio_regs;

/*
    Initialize the given GPIO by:
    - Clear the output enable (i.e. set to input). 
    - Clear the output value for the given GPIO
    @params[in]: gpio   GPIO number
    @return:     none
*/
void gpio_init(uint32_t gpio);

/*
    Set a single GPIO direction as input or output

    @params[in]: gpio       GPIO pin number
    @params[in]: direction  true for out, false for in
    @return:     none
*/
void gpio_set_dir(uint32_t gpio, bool direction);

/*
    Get the direction for the given specific GPIO
    @params[in]: gpio	GPIO number
    @return:     true (1) for out, false(0) for in

*/
bool gpio_get_dir(uint32_t gpio);

/*
    Drive a single GPIO high/low.
    @param[in]: gpio    GPIO pin number
    @param[in]: value   false: clear the pin,
                        true: set the pin
    @return: none
*/
void gpio_put(uint32_t gpio, bool value);

/*
    Drive all the GPIO pins simultaneously.
    @param[in]: value   bitmask of GPIO values to change
    @return: none
*/
void gpio_put_all(uint32_t value);

/*
    Get state of a single specified GPIO
    @param[in]: gpio    GPIO pin number
    @return:    Current state of the GPIO.
                0: low,
                non-zero: high
*/
bool gpio_get(uint32_t gpio);

/*
    Get the raw value for all GPIO pins
    @return:    Current state of all the GPIO pins
*/
uint32_t gpio_get_all();

/*
    Free up any memory that was allocated for the structs
    Call this at the end of the program to deallocate the block of memory pointed at by ptr gpio_regs
*/
void cleanup_gpio();