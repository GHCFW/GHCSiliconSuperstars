#include <cstdio>
#include <string>
#include "gpio/gpio.h"
#include "api/api.h"

#if defined(RUN_UNIT_TESTS)
// Include Catch2 unit testing framework
#include "catch2/catch_test_macros.hpp"

uint32_t test_pin = 22;

TEST_CASE("Test Case 1: Test GPIO init") {
    gpio_init(test_pin);
    REQUIRE( gpio_regs->gpio_oe_clr == (1 << test_pin));
    REQUIRE( gpio_regs->gpio_clr == (1 << test_pin));
}

TEST_CASE("Test Case 2: Test GPIO_SET_DIR sets pin direction to out") {
    gpio_set_dir(test_pin, GPIO_OUT);
    REQUIRE( gpio_regs->gpio_oe_set == (1 << test_pin));
}

TEST_CASE("Test Case 3: Test GPIO_SET_DIR sets pin direction to in") {
    gpio_set_dir(test_pin, GPIO_IN);
    REQUIRE( gpio_regs->gpio_oe_clr == (1 << test_pin));
}

TEST_CASE("Test Case 4: Test GPIO_GET_DIR returns direction for the given pin") {
    gpio_set_dir(test_pin, GPIO_IN);
    REQUIRE( gpio_get_dir(test_pin) == GPIO_IN);
    gpio_set_dir(test_pin, GPIO_OUT);
    REQUIRE( gpio_get_dir(test_pin) == GPIO_OUT);
}

TEST_CASE("Misc: Clean up dangling pointers") {
    cleanup_gpio();
}
#endif