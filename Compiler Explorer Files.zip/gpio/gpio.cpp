// File for HW API that we abstracted here
#include "gpio.h"
#include <unistd.h>


// #if defined(RASPBERRY_PI_PICO)
// #define GPIO_BASE_ADDR (0xd0000000) // Base Addr for SIO/GPIO as defined in the Raspberry Pi Pico SDK
// gpio_registers_t *gpio_regs = (gpio_registers_t *)GPIO_BASE_ADDR;
// #endif

gpio_registers_t* gpio_regs = (gpio_registers_t*)malloc(sizeof(gpio_registers_t));

void gpio_init(uint32_t gpio) {
    // <Test Case 1: FILL CODE HERE>
}

static inline void gpio_set_dir_out(uint32_t mask) {
    //printf("Update the direction of the given GPIO pin to output\n");
    gpio_regs->gpio_oe_set = mask;
    // TODO: clear that bit position in gpio_oe_clr
    //gpio_regs->gpio_oe_clr = ~mask;
 }
  
 static inline void gpio_set_dir_in(uint32_t mask) {
    //printf("Update the direction of the given GPIO pin to input\n");
    gpio_regs->gpio_oe_set = ~mask;
    gpio_regs->gpio_oe_clr = mask;
 }
  
void gpio_set_dir(uint32_t gpio, bool direction) {
    //uint32_t mask = 1ul << gpio;
    printf("Set the direction for the given GPIO as: 0%d\n", direction);
    if (direction == GPIO_OUT) {
        // <Test Case 2: FILL CODE HERE>
    } else if (direction == GPIO_IN) {
        // <Test Case 3: FILL CODE HERE>
    } else {
        printf("%s: Invalid direction: %d provided\n", __func__, direction);
    }
}

bool gpio_get_dir(uint32_t gpio) {
    // <Test Case 4: FILL CODE HERE. 
    // HINT: When gpio_regs->gpio_oe_set [gpio] is 1 it is GPIO_OUT else GPIO_IN>
    return false;
}

inline bool gpio_get(uint gpio) {
    return !!((1ul << gpio) & gpio_regs->gpio_in);
} 
  
inline uint32_t gpio_get_all(void) {
    return gpio_regs->gpio_in;
}
  
static inline void gpio_set_mask(uint32_t mask) {
    gpio_regs->gpio_set = mask;
    // HW would update this register but since we are running this OFF TARGET
    gpio_regs->gpio_out = mask;
}
  
static inline void gpio_clr_mask(uint32_t mask) {
    gpio_regs->gpio_clr = mask;
    // HW would update this register but since we are running this OFF TARGET
    gpio_regs->gpio_in = mask;
}
  
void gpio_put(uint gpio, bool value) {
    uint32_t mask = 1ul << gpio;
    if (value)
        gpio_set_mask(mask);
    else
        gpio_clr_mask(mask);
}

  
inline void gpio_put_all(uint32_t value) {
    gpio_regs->gpio_out = value;
}

void cleanup_gpio() {
    free(gpio_regs);
}
