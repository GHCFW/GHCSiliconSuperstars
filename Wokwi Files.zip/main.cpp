#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/timer.h"
#include "hardware/irq.h"

#define LED_PIN (PICO_DEFAULT_LED_PIN)
#define SLEEP_IN_MS (1000)

#define ALARM_NUM 0
#define ALARM_IRQ TIMER_IRQ_0

void enable_gpio_pin(int led_pin) {
    gpio_init(led_pin);
}

void set_gpio_out(int led_pin) {
    gpio_set_dir(led_pin, GPIO_OUT);
}

void program_gpio_pin(int pin, int value) {
    gpio_put(pin, value);
}

/* Wokwi Exercise 1: Begin*/
void blink_led() {
    // Exercise 1: Blink LED
    /* Copy code from Compiler Explorer here */
    // Exercise 1: FILL CODE HERE
}
/* Wokwi Exercise 1: End*/

/* Wokwi Exercise 2: Begin*/
void toggle_led(int pin) {
    // Exercise 2: Toggle LED
    // Exercise 2: FILL CODE HERE
}

void blink_led_through_toggle() {
    toggle_led(LED_PIN);
    sleep_ms(SLEEP_IN_MS);
}
/* Wokwi Exercise 2: End*/

/* Wokwi Exercise 3: Begin*/
// Alarm interrupt handler
static volatile bool alarm_fired;

static void alarm_irq(void) {
    // Exercise 3: Timer based toggle LED by implementing an interrupt handler routine
    // Clear the alarm irq
    hw_clear_bits(&timer_hw->intr, 1u << ALARM_NUM);
    // Assume alarm 0 has fired
    // Exercise 3: FILL CODE HERE
}

static void alarm_in_us(uint32_t delay_us) {
    alarm_fired = false;
    // Enable the interrupt for our alarm (the timer outputs 4 alarm irqs)
    hw_set_bits(&timer_hw->inte, 1u << ALARM_NUM);
    // Set irq handler for alarm irq
    irq_set_exclusive_handler(ALARM_IRQ, alarm_irq);
    // Enable the alarm irq
    irq_set_enabled(ALARM_IRQ, true);
    // Enable interrupt in block and at processor

    // Alarm is only 32 bits so if trying to delay more than that 
    // then you need to be careful and keep track of the upper bits
    uint64_t target = timer_hw->timerawl + delay_us;

    // Write the lower 32 bits of the target time to the alarm which will arm it
    timer_hw->alarm[ALARM_NUM] = (uint32_t) target;
}
/* Wokwi Exercise 3: End*/

int main() {
    stdio_init_all();
    printf("Hello, GHC Participants!\n");

    enable_gpio_pin(LED_PIN);
    set_gpio_out(LED_PIN);

    int iteration_id_exercise_1 = 0;
    int number_of_iterations_exercise_1 = 3;
    printf("You will be running %d iterations of Blink LED.\n", number_of_iterations_exercise_1);

    while (iteration_id_exercise_1 < number_of_iterations_exercise_1) {
        printf("Running Exercise 1: Blink LED, Iteration: %d\n", iteration_id_exercise_1 + 1);
        blink_led();
        iteration_id_exercise_1++;
    }

    int iteration_id_exercise_2 = 0;
    int number_of_iterations_exercise_2 = 3;
    while (iteration_id_exercise_2 < number_of_iterations_exercise_2) {
        // Exercise 2: Replace blink with toggle LED
        printf("Running Exercise 2: Blink LED through toggle, Iteration: %d\n", iteration_id_exercise_2 + 1);
        blink_led_through_toggle();
        iteration_id_exercise_2++;
    }

    int iteration_id_exercise_3 = 0;
    int number_of_iterations_exercise_3 = 3;
    printf("You will be running %d iterations of Interrupt handler routine to toggle LED.\n", number_of_iterations_exercise_3);
    
    while (iteration_id_exercise_3 < number_of_iterations_exercise_3) {
        printf("Running Exercise 3, Iteration: %d\n", iteration_id_exercise_3 + 1);
        alarm_in_us(1000000);
        while (!alarm_fired);
        iteration_id_exercise_3++;
    }
    return 0;
}


